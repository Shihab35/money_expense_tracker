import 'package:equatable/equatable.dart';

abstract class CalenderViewEvent extends Equatable{
  const CalenderViewEvent();

  @override
  List<Object> get props => [];
}

class LoadCalenderView extends CalenderViewEvent{
  @override
  List<Object> get props => [];
}